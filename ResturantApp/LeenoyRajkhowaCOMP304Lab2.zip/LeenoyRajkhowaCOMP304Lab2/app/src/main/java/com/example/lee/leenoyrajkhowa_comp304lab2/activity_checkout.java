package com.example.lee.leenoyrajkhowa_comp304lab2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class activity_checkout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__check_out);
    }
}
